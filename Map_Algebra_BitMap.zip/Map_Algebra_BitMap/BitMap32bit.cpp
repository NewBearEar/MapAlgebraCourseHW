#include "pch.h"
#include "BitMap32bit.h"


BitMap32bit::BitMap32bit()
{
}


BitMap32bit::~BitMap32bit()
{
}


BITMAPTYPE BitMap32bit::getType()
{
	// TODO: �ڴ˴�����ʵ�ִ���.
	return BITMAPTYPE::BIT32;
}
