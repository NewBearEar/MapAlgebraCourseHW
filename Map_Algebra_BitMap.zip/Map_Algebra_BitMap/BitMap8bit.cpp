#include "pch.h"
#include "BitMap8bit.h"


BitMap8bit::BitMap8bit()
{
}


BitMap8bit::~BitMap8bit()
{
}


BITMAPTYPE BitMap8bit::getType()
{
	// TODO: �ڴ˴�����ʵ�ִ���.
	return BITMAPTYPE::BIT8;
}
