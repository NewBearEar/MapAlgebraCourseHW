#include "pch.h"
#include "DistanceTemplate.h"


DistanceTemplate::DistanceTemplate()
{
}


DistanceTemplate::~DistanceTemplate()
{
}
