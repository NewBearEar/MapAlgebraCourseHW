#include "pch.h"
#include "MyPoint.h"


MyPoint::MyPoint()
{
}


MyPoint::~MyPoint()
{
}
